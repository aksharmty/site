<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <link rel='shortcut icon' href='logo.jpg' type='image/x-icon' />
        <meta name="msvalidate.01" content="F1178E06F62827B2DD8EF2FE31CC0EBF" />
        <title>Mantra Diksha</title>
        <meta name="description" content="get diksha and boost your mantra power">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Fonts -->
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'>

        <!-- Bootsrap -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <!-- Font awesome -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!-- Owl carousel -->
        <link rel="stylesheet" href="assets/css/owl.carousel.css">

        <!-- Template main Css -->
        <link rel="stylesheet" href="assets/css/style.css">
        
        <!-- Modernizr -->
        <script src="assets/js/modernizr-2.6.2.min.js"></script>

    </head>

    <body>
<?php include "header.php" ?>
       <div class="section-home our-causes">

        <div class="container">

            <h2 class="title-style-1">Diksha for success in Mantra sadhana <span class="title-under"></span></h2>

            <div class="row">

                <div class="col-md-9">            
                                <img src="k1.png" alt="diksha for success in mantra" width="100%" height="250px"><br><br>
Every word is mantra and every word have unlimited energy. If you continue chat any word , Its generate energy as per your thought for your . If you you chant mantra after get mantra diksha  then yours increasing your mantra power . 
<br>
Its means mantra diksha increas power of mantra.<br><br>
 
<b>For mantra diksha send your birth details:</b><br><br>
	    	
<b>Your Email Address <br>
Name <br>
Phone No.<br>
Birth Date<br>
Birth Time<br>
Birth Place<br>
Your Problem<br>

Send Details at Email : aksharmty@ymail.com<br>
For Whatsapp No.<a href="https://api.whatsapp.com/send?phone=919213816442"target="_blank">Click here</a>
<br><br>
<table border="0" cellpadding="0" cellspacing="0"><tbody><tr><td><b><font color="#ff0000" face="Arial" size="4">1. Guru Diksha</font></b></td><td><font color="#ff0000" face="Arial" size="4">becoming a disciple through the first initiation.</font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">2. Gyan Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to attain extraordinary knowledge
 and increase in brilliance. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">3. Jeevan Marg Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to make the life lively. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">4. Shambhavi Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to attain "Shivamaya" after 
receiving "Shivatava". </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">5. Chakra Jagran Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">a Diksha to awaken all "Shata 
Chakras" (six chakras). </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">6. Vidya Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to transform an ordinary child 
into intelligent being. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">7. Shishyabhishek Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">complete surrender of oneself to 
become a perfect disciple. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">8. Aacharyabhishek Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to attain the totality of 
knowledge. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">9. Kundalini Jagran Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">An extraordinary personality can 
be attained by this Diksha having seven stages. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">10. Garbhastha Shishu Chaitanaya 
Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">To
 enlighten an offspring in the womb. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">11. Shaktipat Yukt Kundalini 
Jagran Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">Transferring of Guru's Tapa-Energy into the disciple's body to 
attain the "Ultimate Truth" of the life.</font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">12. Kundalini Jagran Diksha 
through a photograph </font></b></td><td><font color="#ff0000" face="Arial" size="4">Kundalini Jagran Diksha is attained on a 
photograph of a disciple. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">13. Dhanvantri Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to attain the perfect state of 
health. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">14. Sabar Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to get success in a Tantrik Sadhana. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">15. Sammohan Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to acquire extraordinary 
attraction in the body. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">16. Sampoorn Sammohan Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to acquire the art of attracting 
everyone. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">17. Mahalakshmi Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to get the monetary benefits and 
attaining prosperity. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">18. Kanakdhara Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">a Diksha for incessant flow of 
money. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">19. Ashta Lakshmi Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">a special Diksha to get unusual 
opulence. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">20. Kuber Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to attain the riches and prosperity permanently. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">21. Indra Vaibhav Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to attain fame and wealth. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">22. Shatru Samharak Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to overcome the enemies. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">23. Apsara Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to Siddh (to control) an Apsara. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">24. Rin Mukti Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to get rid of debts. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">25. Shatopanthi Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to attain the extraordinary power
 of the Lord Shiva. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">26. Chaitanaya Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">a Diksha to invigorate and to 
attain full enlightenment. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">27. Urvasi Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to attain youthfulness and get 
rid of aging. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">28. Sondaryottama Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to increase the beauty. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">29. Menaka Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to attain the physical success in
 life. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">30. Swarnprabha Yakshini Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to get the unanticipated money. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">31. Poorna Vaibhav Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to get all types of luxuries and 
wealth. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">32. Gandharva Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to attain perfection in music. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">33. Sadhana Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to link the previous birth 
Sadhana to this birth. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">34. Tantra Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to get success in Tantrik 
Sadhanas. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">35. Baglamukhi Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to overcome the enemies. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">36. Raseshwari Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to attain perfection in chemistry
 and mercury science. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">37. Aghor Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to get full success in Shiv 
Sadhanas. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">38. Shighra Vivaha Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">for early marriage. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">39. Sammohan Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">an important Diksha having three 
stages. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">40. Veer Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to do the Veer Sadhana. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">41. Sondarya Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to attain the rare beauty. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">42. Jagdamba Siddhi Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to please the goddess Jagdamba. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">43. Brahma Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to attain the divine powers. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">44. Swasthaya Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to attain the disease free 
health. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">45. Karna Pisachini Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to know the past and present of an
 individual. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">46. Sarpa Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to get rid of snake bite and life 
security from it. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">47. Navarna Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to siddha (control) the Tripower 
(Trishakti). </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">48. Garbhastha Shishu Kundalinin Jagran Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">Offspring in a womb gets the 
samskars of a Superhuman. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">49. Chaakshusmati Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to increase the eye vision. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">50. Kaal Gyan Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to attain the knowledge of Time 
(Kaal). </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">51. Tara Yogini Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to get the unexpected money. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">52. Rog Nivaran Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to get rid of all the diseases. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">53. Poornatava Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">a Diksha to attain the Totality 
in the life. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">54. Vaayu Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to make oneself as light as air. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">55. Kritya Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to attain the Siddhi (to control)
 to ruin somebody completely. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">56. Bhoot Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">a Diksha to control ghosts 
completely. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">57. Aagya Chakra Jagran Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to attain the rare vision. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">58. General Vaital Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to get control over Vaital. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">59. Special Vaital Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to get control over Vaital 
completely. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">60. Panchanguli Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to get perfection in the 
palmistry. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">61. Anang Rati Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to attain beauty and youth power. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">62. Krishanatava Guru Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to get the powers of the 
spiritual masters of the world. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">63. Hairamb Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to please the Lord Ganapati. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">64. Haadi-Kaadi Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to get control over sleep, hunger
 and thirst. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">65. Aayurved Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to attain special distinction in 
the field of Aayurved. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">66. Varahmihir Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to attain special distinction in 
the field of Astrology. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">67. Tantrokta Guru Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to get the powers from the 
spiritual Master (guru). </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">68. Garbha Chayan Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to get the desired pregnancy. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">69. Nikhileshwaranand Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to get special powers of Sanyasi.
 </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">70.
 Deerghaayu Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to get a big span of life. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">71. Aakash gaman Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">The soul travels in the sky by 
this Diksha. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">72. Nirbeej Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to end the shackles of life, death
 and Karma. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">73. Kriya Yog Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to attain the knowledge of Jeeva 
(soul) and Brahma. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">74. Siddhashram Pravesh Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">paves the way to enter into 
Siddhashram. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">75. Sodash Apsara Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to get every type of comfort and 
wealth in the life. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">76. Shodasi Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">a diksha for attaining sixteen 
Kalas "Tripur Sundari " Sadhana.</font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">77. Brahmanand Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to attain the knowledge of 
infinite secrets of the Universe. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">78. Paashupaateya Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to fuse oneself with the Lord 
Shiva. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">79. Kapila Yogini Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to get control over Kapila Yogini.
 </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">80.
 Ganapati Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to please the Lord Ganapati and getting their special 
blessings. </font></td></tr><tr><td><b><font color="#ff0000" face="Arial" size="4">81. Vaagdevi Diksha </font></b></td><td><font color="#ff0000" face="Arial" size="4">to get the capacity to speak 
profoundly. </font></td></tr></tbody></table>
</font><p><font face="Arial, Helvetica, sans-serif" size="2"><font color="#ff0000" face="Arial" size="4">In reality it is only by good fate
 that a person is able to get Diksha, and he/she are initiated into a 
process of coming close to his Guru by obeying His instructions.</font></font></p><font face="Arial, Helvetica, sans-serif" size="2">
</font><p><font face="Arial, Helvetica, sans-serif" size="2"><font color="#ff0000" face="Arial" size="4">One should become the disciple of 
such Guru and get various Dikshas from Him so that the completeness of 
the soul and the life can be attained, which are the actual 
manifestations of the process of getting Diksha.</font></font></p><font face="Arial, Helvetica, sans-serif" size="2">
</font></td>
</tr>
</tbody></table>                          
                        
<br><br>
                                            
                </div>


                
                 <div class="col-md-3 col-sm-6">

                 <?php include "sidebar.php" ?>

                </div>

            </div>

        </div>
        
    </div> <!-- /.our-causes -->


    


    <footer class="main-footer">
<?php include "footer.php" ?>
<!--  Scripts
    ================================================== -->

    <!-- jQuery -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/jquery-1.11.1.min.js"><\/script>')</script>

    <!-- Bootsrap javascript file -->
    <script src="assets/js/bootstrap.min.js"></script>
    
    <!-- owl carouseljavascript file -->
    <script src="assets/js/owl.carousel.min.js"></script>

    <!-- Template main javascript -->
    <script src="assets/js/main.js"></script>
</footer>
</body>
</html>