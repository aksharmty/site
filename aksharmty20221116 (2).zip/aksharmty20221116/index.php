<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <link rel='shortcut icon' href='logo.png' type='image/x-icon' />
        <meta name="msvalidate.01" content="F1178E06F62827B2DD8EF2FE31CC0EBF" />
        <title>अक्षर मंत्र तंत्र यंत्र | मंत्र पाठ्यक्रम और मंत्र उपचार केंद्र</title>
        <meta name="description" content="Learn Mantra Sadhana & fulfill your desired">
        <meta name="keyword" content="learn thought process,learn mantra sadhana,mantra,tantra,yantra,mantra tantra,diksha,tantrik,thought process,motivational speaker,thought process trainer,thought process traines in delhi">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Fonts -->
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="assets/css/bootstrap.min.css">

<link rel="stylesheet" href="assets/css/font-awesome.min.css">

<link rel="stylesheet" href="assets/css/owl.carousel.css">

<link rel="stylesheet" href="assets/css/style.css">

<script src="assets/js/modernizr-2.6.2.min.js"></script>
<!--link rel="stylesheet" href="colorbox.css" />
        <script src="colorboxmin.js"></script>
    <script src="colorbox.js"></script>
    <script>
      function openColorBox(){
        $.colorbox({iframe:true, width:"80%", height:"80%", href: "pop.html"});
      }
      
      setTimeout(openColorBox, 5000);
    </script -->

        <!--link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css" -->
<!-- script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script -->
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    </head>

    <body>
         <div id="enquirypopup" class="modal fade in" role="dialog">
<div class="modal-dialog">
<div class="modal-body">
<center>    <a href="diksha.php"><img src="k1.png" width="90%" height="280px"></a>
    </center>
</div>
</div>
</div>
<script>
$(window).load(function(){
        setTimeout(function() {
                $('#enquirypopup').modal('show');
        }, 3000);
            });    </script>
<?php include "header.php" ?> 
    <!-- Carousel
    ================================================== -->
    <div id="homeCarousel" class="carousel slide carousel-home" data-ride="carousel">

          <!-- Indicators -->
          <ol class="carousel-indicators">
            <li data-target="#homeCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#homeCarousel" data-slide-to="1"></li>
            <li data-target="#homeCarousel" data-slide-to="2"></li>
            <li data-target="#homeCarousel" data-slide-to="3"></li>  
          </ol>

          <div class="carousel-inner" role="listbox">

            <div class="item active">

              <img src="assets/images/slider/bg.jpg" alt="" style="width:100%; height:300px; max-height:300px;">

              <div class="container">

                <div class="carousel-caption">

                  <h2 class="carousel-title bounceInDown animated slow" >Learn Mantra Sadhana</h2>
                  <h4 class="carousel-subtitle bounceInUp animated slow"></h4>
                  <h3 class="carousel-subtitle bounceInUp animated slow"></h3>
                  <a href="courses.php" class="btn btn-lg btn-secondary hidden-xs bounceInUp animated slow">Read More</a>

                </div> <!-- /.carousel-caption -->

              </div>

            </div> <!-- /.item -->

            <div class="item ">

              <img src="mantra-diksha.png" alt="" style="width:100%; height:300px; max-height:300px;">

              <div class="container">

                <div class="carousel-caption">

                  <h2 class="carousel-title bounceInDown animated slow" >Mantra Diksha</h2>
                  <h4 class="carousel-subtitle bounceInUp animated slow"></h4>
                  <a href="diksha.php" class="btn btn-lg btn-secondary hidden-xs bounceInUp animated slow">Read More</a>

                </div> <!-- /.carousel-caption -->

              </div>

            </div> <!-- /.item -->

<div class="item ">

              <img src="mala.jpg" alt="" style="width:100%; height:300px; max-height:300px;">

              <div class="container">

                <div class="carousel-caption">

                  <h2 class="carousel-title bounceInDown animated slow" >मन्त्र सिद्ध माला</h2>
                  <h4 class="carousel-subtitle bounceInUp animated slow"></h4>
                  <a href="mantra-siddhi-mala.php" class="btn btn-lg btn-secondary hidden-xs bounceInUp animated slow">Read More</a>

                </div> <!-- /.carousel-caption -->

              </div>

            </div> <!-- /.item -->

            <div class="item ">

              <img src="mantra-consult.png" alt="" style="width:100%; height:300px; max-height:300px;">

              <!-- div class="container">

                <div class="carousel-caption">

                  <h2 class="carousel-title bounceInDown animated slow" >Mantra & Sadhana Consultancy</h2>
                  <h4 class="carousel-subtitle bounceInUp animated slow"></h4>
                  <a href="consult.php" class="btn btn-lg btn-secondary hidden-xs bounceInUp animated slow">Read More</a>

                </div> <!-- /.carousel-caption -->

              </div -->

            </div> <!-- /.item -->

          </div>

          <a class="left carousel-control" href="#homeCarousel" role="button" data-slide="prev">
            <span class="fa fa-angle-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>

          <a class="right carousel-control" href="#homeCarousel" role="button" data-slide="next">
            <span class="fa fa-angle-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>

    </div><!-- /.carousel -->
<div class="section-home our-causes">

        <div class="container">
    
            <h2 class="title-style-1">Our Services <span class="title-under"></span></h2>

            <div class="row">

                <div class="col-md-12 col-sm-6">
                    <div class="col-md-9 col-sm-6">
                    <div class="col-md-4 col-sm-6">

                    <div class="cause">

                        <img src="assets/images/slider/bg.jpg" alt="" class="cause-img" height="100px">

                        <h4 class="cause-title"><a href="#">Learn Mantra Sadhana </a></h4>
                        <div class="cause-details">
                            Learn mantra sadhana and fulfill your desired .
                        </div>

                        <div class="btn-holder text-center">

                          <a href="courses.php" class="btn btn-primary"> Read More</a>
                          
                        </div>

                        

                    </div> <!-- /.cause -->
                    
                </div> 

                <div class="col-md-4 col-sm-6">

                    <div class="cause">

                         <img src="mantra-diksha.png" alt="mantra diksha" class="cause-img" height="100px">

                        <h4 class="cause-title"><a href="#">Get Mantra Diksha </a></h4>
                        <div class="cause-details">
                            Get mantra diksha and boost your mantra power.
                        </div>

                        <div class="btn-holder text-center">

                          <a href="diksha.php" class="btn btn-primary">Read More</a>
                          
                        </div>

                        

                    </div> <!-- /.cause -->
                    
                </div>


                <div class="col-md-4 col-sm-6">

                    <div class="cause">

                       <img src="mantra-consult.png" alt="" class="cause-img" height="100px">

                        <h4 class="cause-title"><a href="#">Consult Your Problem </a></h4>
                        <div class="cause-details">
                           Get solution for your problem using mantra jaap.
                        </div>

                        <div class="btn-holder text-center">

                          <a href="consult.php" class="btn btn-primary">Read More</a>
                          
                        </div>

                        

                    </div> <!-- /.cause -->
                    
                </div>

                <div class="col-md-4 col-sm-6">

                    <div class="cause">

                        <img src="mala.jpg" alt="" class="cause-img" height="100px">

                        <h4 class="cause-title"><a href="mantra-siddhi-mala.php">मन्त्र सिद्ध माला </a></h4>
                        <div class="cause-details">
                           मंत्र सिद्ध माला सभी कार्य व साधना के लिए कारगर हैं | 
                        </div>

                        <div class="btn-holder text-center">

                          <a href="mantra-siddhi-mala.php" class="btn btn-primary">Read More</a>
                          
                        </div>

                        

                    </div> <!-- /.cause -->
                    
                </div>
                <div class="col-md-4 col-sm-6">

                    <div class="cause">

                        <img src="assets/images/slider/bg.jpg" alt="" class="cause-img" height="100px">

                        <h4 class="cause-title"><a href="#">Yantra Siddhi </a></h4>
                        <div class="cause-details">
                            Learn how to siddhi any Yantra.
                        </div>

                        <div class="btn-holder text-center">

                          <a href="contact.php" class="btn btn-primary">Read More</a>
                          
                        </div>

                        

                    </div> <!-- /.cause -->
                    
                </div>
                <div class="col-md-4 col-sm-6">

                    <div class="cause">

                        <img src="mantra-healing.png" alt="" class="cause-img" height="100px">

                        <h4 class="cause-title"><a href="#">Mantra Healing </a></h4>
                        <div class="cause-details">
                            Heal your mind and body using Mantra Healing .
                        </div>

                        <div class="btn-holder text-center">

                          <a href="mantra-healing.php" class="btn btn-primary">Read More</a>
                          
                        </div>

                        

                    </div> <!-- /.cause -->
                    
                </div>
                        
        
                <div class="col-md-4 col-sm-6">

                    <div class="cause">

                         <img src="assets/images/slider/bg.jpg" alt="" class="cause-img" height="100px">

                        <h4 class="cause-title"><a href="#">Mantra Sadhana </a></h4>
                        <div class="cause-details">
                            Do mantra sadhana for your desire .
                        </div>

                        <div class="btn-holder text-center">

                          <a href="sadhana.php" class="btn btn-primary">Read More</a>
                          
                        </div>

                        

                    </div> <!-- /.cause -->
                    
                </div>
               <div class="col-md-4 col-sm-6">

                    <div class="cause">

                        <img src="https://m.media-amazon.com/images/I/41wv9tF+4eS._SY346_.jpg" alt="" class="cause-img" height="100px">

                        <h4 class="cause-title"><a href="#">Book </a></h4>
                        <div class="cause-details">
                            51 mantra sangrah by raj kumar .
                        </div>

                        <div class="btn-holder text-center">

                          <a href="https://www.amazon.in/dp/B095J3TKBB/" target="_blank" class="btn btn-primary">Read More</a>
                          
                        </div>

                        

                    </div> <!-- /.cause -->
                    
                </div>
               <div class="col-md-4 col-sm-6">

                    <div class="cause">

                        <img src="dedicatedserver.png" alt="" class="cause-img" height="100px">

                        <h4 class="cause-title"><a href="#">Server Hosting </a></h4>
                        <div class="cause-details">
                            Run trading bot or host your website on server .
                        </div>

                        <div class="btn-holder text-center">

                          <a href="https://sakhihosting.in/dedicated-servers.php" class="btn btn-primary">Read More</a>
                          
                        </div>

                        

                    </div> <!-- /.cause -->
                    
                </div>
                        
       
    </div> <!-- /.our-causes -->
<div class="col-md-3 col-sm-6">

    <?php include "sidebar.php" ?> 
</div>
</div></div>
        </div>
        
    </div> <!-- /.our-causes -->
  
    <footer class="main-footer">
 <?php include "footer.php" ?> 
<!--  Scripts
    ================================================== -->

    <!-- jQuery -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/jquery-1.11.1.min.js"><\/script>')</script>

    <!-- Bootsrap javascript file -->
    <script src="assets/js/bootstrap.min.js"></script>
    
    <!-- owl carouseljavascript file -->
    <script src="assets/js/owl.carousel.min.js"></script>

    <!-- Template main javascript -->
    <script src="assets/js/main.js"></script>

</footer>
</body>
</html>