<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <link rel='shortcut icon' href='logo.jpg' type='image/x-icon' />
        <meta name="msvalidate.01" content="F1178E06F62827B2DD8EF2FE31CC0EBF" />
        <title>Beej Mantra Learning Class | Akshar Mantra Tantra Yantra</title>
        <meta name="description" content="learn Beej mantra ">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Fonts -->
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'>

        <!-- Bootsrap -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <!-- Font awesome -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!-- Owl carousel -->
        <link rel="stylesheet" href="assets/css/owl.carousel.css">

        <!-- Template main Css -->
        <link rel="stylesheet" href="assets/css/style.css">
        
        <!-- Modernizr -->
        <script src="assets/js/modernizr-2.6.2.min.js"></script>

    </head>

    <body>
<?php include "header.php" ?>
       <div class="section-home our-causes">

        <div class="container">

            <h2 class="title-style-1">Beej Mantra Learning Class <span class="title-under"></span></h2>

            <div class="row">          

                <div class="col-md-9 col-sm-6">

                    <div class="cause">

                        <div class="cause-details">
                        <h3>  
                    
					<p>
You can learn in this class :<br>
<b>*</b>What is mantra ?<br>
<b>*</b>Why siddh Beej mantra ?<br>
<b>*</b>Use of Beej mantra ?<br>
<b>*</b>How to siddh Beej mantra in kumar mantra sadhana method ?<br>
<b>*</b>Advantage of Beej mantra sadhana ?<br>
<b>*</b>What is different between varn mantra and Beej Mantra ?<br>
<b>*</b>Information of 21 Beej Mantra Samany Guru Mantra sadhana method and diksha<br>

<b>Duration : 4 Hours</b><br>
<b>Fee : INR.11000</b><br>
<font size="3" color="#ff0000"> AFTER CLASS DO MANTRA SADHANA OWN YOUR HOME AS PER NEED</font><BR>
<b>NOTE : We does not provide any CERTIFICATE in any class.<br>
Mantra sadhana siddhi depend on sadhak's faith and devotion on Guru , Isht and Mantra.</b><br></font>

<br>
</p>
                         </h3><br>
                        <div class="btn-holder text-center"><br>

                          <a href="contact.php" class="btn btn-primary" >Contact Now</a>
                          
                        </div>
<br><br>
                        </div>

                    </div> <!-- /.cause -->
                    
                </div>


                
                 <div class="col-md-3 col-sm-6">

                   <?php include "sidebar.php" ?>

                </div>

            </div>

        </div>
        
    </div> <!-- /.our-causes -->


    


    <footer class="main-footer">
<?php include "footer.php" ?>

<!--  Scripts
    ================================================== -->

    <!-- jQuery -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/jquery-1.11.1.min.js"><\/script>')</script>

    <!-- Bootsrap javascript file -->
    <script src="assets/js/bootstrap.min.js"></script>
    
    <!-- owl carouseljavascript file -->
    <script src="assets/js/owl.carousel.min.js"></script>

    <!-- Template main javascript -->
    <script src="assets/js/main.js"></script>
   
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-103796334-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-103796334-1');
</script>
</footer>
</body>
</html>
