<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <link rel='shortcut icon' href='logo.jpg' type='image/x-icon' />
        <meta name="msvalidate.01" content="F1178E06F62827B2DD8EF2FE31CC0EBF" />
        <title>रोग निवारण के लिए मन्त्र हीलिंग | Akshar Mantra Tantra Yantra</title>
        <meta name="description" content="मंत्र चिकित्सा एक वैकल्पिक चिकित्सा पद्धति है। मंत्र चिकित्सा रोगियों को अधिक ब्रह्मांडीय ऊर्जा आकर्षित करती है और जीवन के लिए इच्छा शक्ति को बढ़ाती है। इच्छा शक्ति के बिना जीवन संभव नहीं है। इस उपचार पद्धति का कोई साइड इफेक्ट नहीं है, इसलिए यह पूरी तरह से सुरक्षित है। ">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Fonts -->
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'>

        <!-- Bootsrap -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <!-- Font awesome -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!-- Owl carousel -->
        <link rel="stylesheet" href="assets/css/owl.carousel.css">

        <!-- Template main Css -->
        <link rel="stylesheet" href="assets/css/style.css">
        
        <!-- Modernizr -->
        <script src="assets/js/modernizr-2.6.2.min.js"></script>

    </head>

    <body>
<?php include "header.php" ?>
       <div class="section-home our-causes">

        <div class="container">

            <h2 class="title-style-1">रोग निवारण के लिए मन्त्र हीलिंग <span class="title-under"></span></h2>

            <div class="row">          

                <div class="col-md-9 col-sm-6">

                    <div class="cause">

                        <div class="cause-details">
                        <h3>  
                    
					<p>
<b>मंत्र चिकित्सा :</b><br>
मंत्र चिकित्सा एक वैकल्पिक चिकित्सा पद्धति है। मंत्र चिकित्सा रोगियों को अधिक ब्रह्मांडीय ऊर्जा आकर्षित करती है और जीवन के लिए इच्छा शक्ति को बढ़ाती है। इच्छा शक्ति के बिना जीवन संभव नहीं है। इस उपचार पद्धति का कोई साइड इफेक्ट नहीं है, इसलिए यह पूरी तरह से सुरक्षित है। <br>
ये फ्रैक्चर को छोड़कर सभी बीमारियों में कारगर हैं।
<br>मन्त्र उपचार कम से कम तीन दिन अवश्य ले |<br>
<b>नोट : </b> डिस्टेंस मंत्र हीलिंग प्रत्यक्ष मंत्र हीलिंग के समान काम करती हैैं | तो आप  डिस्टेंस मन्त्र उपचार भी ले सकते हैं | <br>
डिस्टेंस मन्त्र उपचार के लिए जातक के फोटो की आवश्यकता होती हैं | 
<br>
<br>
<b>तन्त्र दोष या नज़र दोष :</b><br>
यदि आप लंबे समय से बीमार हैं और चिकित्सक द्वारा उचित दवा भी ले रहे हैं | फिर भी स्वस्थ लाभ नहीं हो रहा हैं | तो आप तन्त्र दोष या नज़र दोष से ग्रस्त हो सकते हैं |<br>
इस का उपचार मन्त्र द्वारा संभव हैं | आप मन्त्र उपचार ले और साथ ही अपने चिकित्सक द्वारा दिया हुआ दवा भी ले | आप देखेंगे कि आपके द्वारा लिया गया दवा , आप पर जल्दी और ज्यादा तेजी से काम कर रहा हैं | जिससे आप की स्वस्थ होने की संभावना बढ़ जाएगी |<br>
</p><HR style="border-top: 5px solid red;">
    <br><p>
<b>Mantra Healing : </b>Mantra Healing is an alternative healing method. Mantra healing attracts more cosmic energy to the patients and boosts will power for life. Life is not possible without will power. This treatment method does not have any side effects, so it is completely safe. <br>
These are effective in all diseases except for the fracture.<br>
<b>Note :</b> Distance Mantra Healing Works Similar to Direct Mantra Healing. So you can also take distance mantra treatment.<br>
The photo of the person is required for distance mantra treatment.<br><br> 
<b>Tantra Dosha or Eye Dosha</b>
If you have been ill for a long time and are also taking proper medicine prescribed by the doctor. Still not getting healthy benefits. So you may suffer from Tantra Dosha or Eye Dosha.<br>
Its treatment is possible through mantra. You take the mantra treatment as well as the medicine given by your doctor. You will notice that the medicine you have taken is working on you faster and more quickly. Which will increase your chances of getting healthy.<br>
Must take mantra treatment for at least three days.<br></p>
<HR style="border-top: 5px solid red;">
     <br>
<b>Duration : 5-15 Minute Daily</b><br>
<b>Fee : INR.1100 per session</b><br>
<b>Disclaimer :</b> Mantra healing work slow, so please for fast result consult your doctor regularly.<br>
<br>

                         </h3><br>
                        <div class="btn-holder text-center"><br>

                          <a href="contact.php" class="btn btn-primary" >Contact Now</a>
                          
                        </div>
<br><br>
                        </div>

                    </div> <!-- /.cause -->
                    
                </div>


                
                 <div class="col-md-3 col-sm-6">

<?php include "sidebar.php" ?>

                </div>

            </div>

        </div>
        
    </div> <!-- /.our-causes -->


    <footer class="main-footer">
<?php include "footer.php" ?>

<!--  Scripts
    ================================================== -->

    <!-- jQuery -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/jquery-1.11.1.min.js"><\/script>')</script>

    <!-- Bootsrap javascript file -->
    <script src="assets/js/bootstrap.min.js"></script>
    
    <!-- owl carouseljavascript file -->
    <script src="assets/js/owl.carousel.min.js"></script>

    <!-- Template main javascript -->
    <script src="assets/js/main.js"></script>
   
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-103796334-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-103796334-1');
</script>
</footer>
</body>
</html