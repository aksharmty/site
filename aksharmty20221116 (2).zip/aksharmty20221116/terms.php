<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <link rel='shortcut icon' href='logo.jpg' type='image/x-icon' />
        <meta name="msvalidate.01" content="F1178E06F62827B2DD8EF2FE31CC0EBF" />
        <title>Terms | Akshar Mantra Tantra Yantra</title>
        <meta name="description" content="Terms and condition for use of Akshar Mantra Tantra Yantra Services ">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Fonts -->
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'>

        <!-- Bootsrap -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <!-- Font awesome -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!-- Owl carousel -->
        <link rel="stylesheet" href="assets/css/owl.carousel.css">

        <!-- Template main Css -->
        <link rel="stylesheet" href="assets/css/style.css">
        
        <!-- Modernizr -->
        <script src="assets/js/modernizr-2.6.2.min.js"></script>

    </head>

    <body>
<?php include "header.php" ?>
       <div class="section-home our-causes">

        <div class="container">

            <h2 class="title-style-1">Terms and Conditions <span class="title-under"></span></h2>

            <div class="row">          

                <div class="col-md-9 col-sm-6">

                    <div class="cause">

                        <div class="cause-details">
                        <h3>  
                    
										<p>
You must be agree for our terms for using our services :<br>
<b>Classes Terms</b><br>
All classes provided without any certificate<br>
All classes provided on your request without any guarantee of success in sadhana.<br>
All classes are without practical , Only theory in class<br> 
You agree to pay all payment in advance<br>
NO REFUND policy
<br>
<b>Mantra Diksha</b><br>
All Diksha given without any sadhana material.<br>
No guarantee for any success in mantra sadhana.<br>

You agree to pay all payment in advance<br>
NO REFUND policy
<br>
<b>Mantra Healing</b><br>
Mantra is God's grace and I am the medium of divine grace only.<br>
All Mantra class provided without any certificate<br>
All type Mantra Healing session ( direct and distance ) provided on your request without any guarantee.<br>
You agree to pay all payment in advance<br>
NO REFUND policy
<br>
</p>
                         </h3><br>
                        <br><br>
                        </div>

                    </div> <!-- /.cause -->
                    
                </div>


                
                 <div class="col-md-3 col-sm-6">

                <?php include "sidebar.php" ?>

                </div>

            </div>

        </div>
        
    </div> <!-- /.our-causes -->


    


    <footer class="main-footer">
<?php include "footer.php" ?>

<!--  Scripts
    ================================================== -->

    <!-- jQuery -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/jquery-1.11.1.min.js"><\/script>')</script>

    <!-- Bootsrap javascript file -->
    <script src="assets/js/bootstrap.min.js"></script>
    
    <!-- owl carouseljavascript file -->
    <script src="assets/js/owl.carousel.min.js"></script>

    <!-- Template main javascript -->
    <script src="assets/js/main.js"></script>
   
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-103796334-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-103796334-1');
</script>
</footer>
</body>
</html>