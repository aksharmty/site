<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4305348743992957"
     crossorigin="anonymous"></script>
     <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-103796334-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-103796334-1');
</script>
<header class="main-header">
        
    
        <nav class="navbar navbar-static-top">

            <div class="navbar-top">

              <div class="container">
                  <div class="row">

                    <div class="col-sm-6 col-xs-12">

                        <ul class="list-unstyled list-inline header-contact">
                            <li> <i class="fa fa-phone"></i> <a href="tel:+919213816442">+919213816442 </a> </li>
                             <li> <i class="fa fa-envelope"></i> <a href="mailto:aksharmty@ymail.com">aksharmty@ymail.com</a> </li>
                            </ul> <!-- /.header-contact  -->
                      
                    </div>

                    <div class="col-sm-6 col-xs-12 text-right">

                        <ul class="list-unstyled list-inline header-social">
<li> <a href="https://www.facebook.com/Akshar-Mantra-Tantra-Yantra-173620303354282/"> <i class="fa fa-facebook"></i> </a> </li>
                            </ul> <!-- /.header-social  -->
                      
                    </div>


                  </div>
              </div>

            </div>

            <div class="navbar-main">
              
              <div class="container">

                <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
MENU
    <!--                <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span> -->

                  </button><table><tr><td>
                 <a href="index.php"><img style="border-radius: 80%" src="logo.png" alt="aksharmty" width="90px"></a>
                 <!--img src="//sakhirajfinance.tk/srflogo.png" width="250px" height="100px" --> </td><td>
                  <a href="index.php"><h2>अक्षर मंत्र तंत्र यंत्र </h2>
                  <H3>मंत्र साधना और मंत्र उपचार केंद्र</H3></td></tr></table></a>
                </div>

                <div id="navbar" class="navbar-collapse collapse pull-right">

                  <ul class="nav navbar-nav">
                     <li><a href="index.php">HOME</a></li>
                     <li><a href="about.php">ABOUT</a></li>
                     <li class="has-child"><a href="#">सीखें </a>
                   <ul class="submenu">                          
                      <li class="submenu-item">
                    <!--li><a href="basic-mantra-class.php">BASIC MANTRA CLASS</a></li>
                    <li><a href="varn-mantra-class.php">VARN MANTRA CLASS</a></li>
                     <li><a href="beej-mantra-class.php">BEEJ MANTRA CLASS</a></li -->
                    <li><a href="dhyan-class.php">इच्छापूर्ति ध्यान सीखें </a></li>
                    <li><a href="mantra-healing-class.php">मंत्र हीलिंग सीखें </a></li>
                    </ul></li>
                   <li></li>
                   <li><a href="diksha.php">DIKSHA</a></li>
                    <li class="has-child"><a href="#">MANTRA HEALING</a>
                     <ul class="submenu">                          
                      <li class="submenu-item">
                    <li><a href="mantra-healing.php">रोग निवारण के लिए </a></li> 
                    <li><a href="mantra-healing-solution.php">समस्या निवारण के लिए </a></li>
                    <li><a href="mantra-healing-class.php">मन्त्र हीलिंग सीखें</a></li>                   
                    </ul></li>                    
                    <li><a href="mantra-siddhi-mala.php">मन्त्र सिद्ध माला</a></li>
                     <li class="has-child"><a href="#">SADHANA</a>
                     <ul class="submenu">                          
                      <li class="submenu-item">
                          <li><a href="sadhana.php">POPULAR SADHANA LIST</a></li>
                          <li><a href="https://mantra.aksharmty.in/"target="_blank">लोकप्रिय मंत्र</a></li>
                          <li><a href="ram-shalaka.php">श्री राम शलाका प्रश्नावली</a></li>
                   </ul></li>
                   <li><a href="payment-option.php">PAYMENT OPTION</a></li>
                   <li><a href="contact.php">CONTACT</a></li>
                   <!-- li><a href="https://docs.google.com/forms/d/e/1FAIpQLSeletkssDcGNuui4J_6rRQdZV64OIla_-zMbMAanh8Roky_6A/viewform?usp=sf_link" target="_blank">CONTACT FORM</a></li -->
                   <!--li class="has-child"><a href="#">PROMOTIONAL LINKS</a>
                     <ul class="submenu">                          
                      <li class="submenu-item">
                          <li><a href="https://sakhihosting.in"TARGET="_BLANK">WEB HOSTING</a></li>
                          <li><a href="https://adquash.com/index.php"target="_blank">FREE CLASSIFIED ADS</a></li>
                          <li><a href="https://sakhiraj-trading-academy.blogspot.com/"target="_blank">LEARN TRADING</a></li>
                          <li><a href="https://aksharmty.github.io/sakhirajfinance/"target="_blank">Finance</a></li>
                   </ul></li -->
                    
                  </ul>

                </div> <!-- /#navbar -->

              </div> <!-- /.container -->
              
            </div> <!-- /.navbar-main -->


        </nav> 

    </header> <!-- /. main-header -->
    <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-4e2c27a05a55037e"></script>
