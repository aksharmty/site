<br>
<?php
$a=array("<a href='https://fxvm.net/?aff=29031' target='blank_'><img src='https://strategyon.co.in/adimg/fxvm.gif' width='300px' height='250px'></a>",
"<a href='https://fbs.com/trading?ppu=5389108' target='_blank' style='outline: none'><img src='https://fbs.com/upload/promo/banner/0e462b3d071b9d6c21510d007d9ca93d.gif?ppu=5389108' width='300' height='250' border='0'></a>",
"<a href='https://www.binance.com/en/register?ref=36845681' target='blank_'><img src='https://strategyon.co.in/binance.jpg' width='300px' height='250px'></a>",
"<a href='https://wazirx.com/invite/mzgsf2ws' target='blank_'><img src='https://strategyon.co.in/adimg/wazir.jpg' width='300px' height='250px'></a>",
"<a href='https://sakhihosting.in/dedicated-servers.php' target='blank_'><img src='https://strategyon.co.in/dedicatedserver.png' width='300px' height='250px'></a>",
//"<a href='https://itrade.angelbroking.com/DiyKyc/SubbrokerLead?SbTag=UktKSg==' target='blank_'><img src='https://strategyon.co.in/demat.png' width='300px' height='250px'></a>",

"<a href='https://www.amazon.in/dp/B09FK66917' target='blank_'><img src='https://m.media-amazon.com/images/I/51yuPQ1Cc9L.jpg' alt='Powerful Trading Strategy Using MA Crossover: POWER OF MA Crossover' width='300px' height='250px'></a>",
"<a href='https://www.amazon.in/dp/B096X73C74' target='blank_'><img src='https://m.media-amazon.com/images/I/41doe8uNvhS.jpg' alt='संक्षिप्त श्री राम कथा हिन्दी में : सरल राम साधना सहित' width='300px' height='250px'></a>",
"<a href='https://www.amazon.in/dp/B095J3TKBB' target='blank_'><img src='https://m.media-amazon.com/images/I/41wv9tF+4eS._SY346_.jpg' alt='51 मंत्र संग्रह' width='300px' height='250px'></a>");
$random_keys=array_rand($a);
echo $a[$random_keys]."<br>";
?>