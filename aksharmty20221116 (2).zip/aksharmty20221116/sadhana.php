<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <link rel='shortcut icon' href='logo.jpg' type='image/x-icon' />
        <meta name="msvalidate.01" content="F1178E06F62827B2DD8EF2FE31CC0EBF" />
        <title>Sadhana List | Akshar Mantra Tantra Yantra</title>
        <meta name="description" content="siddh any sadhana as per your need and enjoy your life ">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Fonts -->
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'>

        <!-- Bootsrap -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <!-- Font awesome -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!-- Owl carousel -->
        <link rel="stylesheet" href="assets/css/owl.carousel.css">

        <!-- Template main Css -->
        <link rel="stylesheet" href="assets/css/style.css">
        
        <!-- Modernizr -->
        <script src="assets/js/modernizr-2.6.2.min.js"></script>

   <style>
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
}

th, td {
  text-align: left;
  padding: 8px;
 border: 1px solid #003366;	
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
 </head>

    <body>
<?php include "header.php" ?>
       <div class="section-home our-causes">

        <div class="container">

            <h2 class="title-style-1">Sadhana List <span class="title-under"></span></h2>

            <div class="row">          

                <div class="col-md-9 col-sm-6">

                    <div class="cause">

                        <div class="cause-details">
                        <h3>  
                    
					<p>
You can siddh any one or more sadhana given below :<br>
<div style="overflow-x:auto;"> 
<!--table><tr><td>Sadhana Name </td><td>Description</td><td>Duration</td><td>Fee in INR.</td></tr>
<tr><td><b>Varn Mantra Sadhana : </b></td><td> You can choose any one varn between ( क - स ) and siddh varn and use in your life.</td><td>3 Months</td><td>7000/mo</td></tr>
<tr><td><b>Beej Mantra Sadhana :</b></td><td>You can choose any one beej mantra श्रीं , ह्रीं , क्लीं , ह्रौं , ह्लीं , ग्लौं , खौं </td><td>3 Months</td><td>7000/mo</td></tr>
<tr><td><b>Maha Vidya Sadhana :</b></td><td>You can choose any one maha vidya mantra काली, तारा, छिन्नमस्ता, षोडशी, भुवनेश्वरी, त्रिपुर भैरवी, धूमावती, बगलामुखी, मातंगी व कमला। 
</td><td>6 Months</td><td>11000/mo</td></tr>
<tr><td><b>Manokamna Purti Sadhana :</b></td><td>You can do sadhana for one wish at onetime (Only general wish)</td><td>6 Months</td><td>11000*/mo</td></tr>
<tr><td><b>Appear Your God Sadhana :</b></td><td>Feel your God in your soul and mind</td><td>12 Months</td><td>21000/month</td></tr>
<tr><td><b>Kundalini Chakra Dal Sadhana :</b></td><td>Active your one chakra dal as per your need</td><td>3 months</td><td>11000/mo</td></tr>
<tr><td><b>Asht Lakshmi Sadhana :</b></td><td>Attract Asht Laxmi in your life (आयु लक्ष्मी , स्वस्थ लक्ष्मी , धन लक्ष्मी , गृहस्थ लक्ष्मी , संतान लक्ष्मी , वैभव लक्ष्मी , वाहन लक्ष्मी , ऐश्वर्य लक्ष्मी )</td><td>9 Months</td><td>15000/mo</td></tr>
	</table -->
1.Samany Guru Sadhana<br>
2. Kundalini Jagran Sadhana<br>
3. Sammohan Sadhana<br>
4. Ashta Lakshmi Sadhana<br>
5. Kuber Sadhana<br>
6. Apsara Sadhana<br>
7. Rin Mukti Sadhana<br>
8. Baglamukhi Sadhana<br>
9. Jagdamba Sadhana<br>
10. Navarna Sadhana<br>
11. Rog Nivaran Sadhana<br>
12. Maha Viddhy Sadhana<br>
	For more sadhana visit <a href="diksha.php">DIKSHA page</a><br>
	<b>NOTE : </b> We only provide Information , guidance , mantra , diksha for sadhana as per kumar mantra sadhana paddhti. <br>
					</div>

<font size="3" color="#ff0000"> AFTER CLASS DO MANTRA SADHANA OWN YOUR HOME AS PER NEED</font><BR>
<b>NOTE : We does not provide any CERTIFICATE in any class.<br>
Mantra sadhana siddhi depend on sadhak's faith and devotion on Guru , Isht and Mantra.</b><br></font>

<br>
</p>
                         </h3><br>
                        <div class="btn-holder text-center"><br>

                          <a href="contact.php" class="btn btn-primary" >Contact Now</a>
                          
                        </div>
<br><br>
                        </div>

                    </div> <!-- /.cause -->
                    
                </div>


                
                 <div class="col-md-3 col-sm-6">

                  <?php include "sidebar.php" ?>

                </div>

            </div>

        </div>
        
    </div> <!-- /.our-causes -->


    


    <footer class="main-footer">
<?php include "footer.php" ?>

<!--  Scripts
    ================================================== -->

    <!-- jQuery -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/jquery-1.11.1.min.js"><\/script>')</script>

    <!-- Bootsrap javascript file -->
    <script src="assets/js/bootstrap.min.js"></script>
    
    <!-- owl carouseljavascript file -->
    <script src="assets/js/owl.carousel.min.js"></script>

    <!-- Template main javascript -->
    <script src="assets/js/main.js"></script>
   
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-103796334-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-103796334-1');
</script>
</footer>
</body>
</html>
