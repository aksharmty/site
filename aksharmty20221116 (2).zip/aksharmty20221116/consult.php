<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <link rel='shortcut icon' href='logo.jpg' type='image/x-icon' />
        <meta name="msvalidate.01" content="F1178E06F62827B2DD8EF2FE31CC0EBF" />
        <title>Consult on Your any doubt with us</title>
        <meta name="description" content="Consult on Your any doubt with us for solution and get best solution">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Fonts -->
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'>

        <!-- Bootsrap -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <!-- Font awesome -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!-- Owl carousel -->
        <link rel="stylesheet" href="assets/css/owl.carousel.css">

        <!-- Template main Css -->
        <link rel="stylesheet" href="assets/css/style.css">
        
        <!-- Modernizr -->
        <script src="assets/js/modernizr-2.6.2.min.js"></script>

    </head>

    <body>
<?php include "header.php" ?>
       <div class="section-home our-causes">

        <div class="container">

            <h2 class="title-style-1">Consultancy <span class="title-under"></span></h2>

            <div class="row">

                <div class="col-md-3 col-sm-6">

                    <center><img src="rajpic.jpg" alt="Mantra Sadhak Mr.Raj Kumar"><br>

                        <h2>Mr.Raj Kumar <br> Mantra Sadhak
                        </h2></center>
                    
                </div> 

                <div class="col-md-6 col-sm-6">

                    <div class="cause">

                        <div class="cause-details">
                        <h3>You have any questions in your mind for your professional life, personal life or mantra sadhana. You can consult with us and get best solution for your question.<br>
We provide solution base on mantra chanting ( jaap ) , mantra diksha , mantra healing and ratna.<br>
Consultancy fee : INR.2100 per hour.<br>
For consultancy please deposit fee in our bank account . 
</h3><br>
                        <div class="btn-holder text-center"><br>
<h3>for Bank Details
                          <a href="payment-option.php" class="btn btn-primary" >click here</a>
 </h3>                         
                        </div>
<br><br>
                        </div>

                    </div> <!-- /.cause -->
                    
                </div>


                
                 <div class="col-md-3 col-sm-6">

                  <?php include "sidebar.php" ?>

                </div>

            </div>

        </div>
        
    </div> <!-- /.our-causes -->


    


    <footer class="main-footer">
<?php include "footer.php" ?>

<!--  Scripts
    ================================================== -->

    <!-- jQuery -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/jquery-1.11.1.min.js"><\/script>')</script>

    <!-- Bootsrap javascript file -->
    <script src="assets/js/bootstrap.min.js"></script>
    
    <!-- owl carouseljavascript file -->
    <script src="assets/js/owl.carousel.min.js"></script>

    <!-- Template main javascript -->
    <script src="assets/js/main.js"></script>
   
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-103796334-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-103796334-1');
</script>
</footer>
</body>
</html>
