<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <link rel='shortcut icon' href='logo.jpg' type='image/x-icon' />
        <meta name="msvalidate.01" content="F1178E06F62827B2DD8EF2FE31CC0EBF" />
        <title>इच्छापूर्ति ध्यान सीखें </title>
        <meta name="description" content="इच्छापूर्ति के लिए इच्छापूर्ति ध्यान सीखें  ">
        <meta property="og:image" content="https://aksharmty.in/dhyan.jpg">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Fonts -->
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'>

        <!-- Bootsrap -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <!-- Font awesome -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!-- Owl carousel -->
        <link rel="stylesheet" href="assets/css/owl.carousel.css">

        <!-- Template main Css -->
        <link rel="stylesheet" href="assets/css/style.css">
        
        <!-- Modernizr -->
        <script src="assets/js/modernizr-2.6.2.min.js"></script>

    </head>

    <body>
<?php include "header.php" ?>
       <div class="section-home our-causes">

        <div class="container">

            <h2 class="title-style-1">इच्छापूर्ति ध्यान सीखें  <span class="title-under"></span></h2>

            <div class="row">          

                <div class="col-md-9 col-sm-6">
<img src="dhyan.jpg" width="100%" height="300px">    
<br>
                    <div class="cause">

                        <div class="cause-details">
                        <h3>  
<p>
हर व्यक्ति के जीवन में कोई न कोई एक इच्छा अधूरी होती हैं जो व्यक्ति पूरा करना चाहता हैं | कई कोशिश के बाद भी इच्छापूर्ति में सफलता नहीं मिल पाती | तो व्यक्ति उदास हो जाता हैं | ये उदासी उसके जीवन में मानसिक या शारीरिक समस्या उत्पन कर सकता हैं |  <br><br>
किसी तरह से अपने इच्छा को अपने अवचेतन मन तक पहुंच दे तो अधूरी इच्छा पूर्ति की सम्भावन बढ़ जाती हैं | अपने इच्छा को अवचेतन मन तक पहुंचाने का एक तरीका ध्यान हैं | ध्यान के माध्यम से आप अपनी इच्छा अवचेतन मन तक पंहुचा कर अपनी अधूरी इच्छा को पूरी होने की सम्भावना को बढ़ा सकते हैं | 
 </p>                    
<p>
अपनी इच्छापूर्ति  के लिए इच्छापूर्ति ध्यान सीखें :<br>
आप जानेगे : <br>
ध्यान करने का उचित समय <br>
ध्यान करने का तरीका <br>
ध्यान से अवचेतन मन को प्रेरित करने का तरीका <br><br>

<b>Duration : 1 Hours</b><br>
<b>Fee : INR.11000</b><br>
<font size="3" color="#ff0000"> AFTER CLASS DO MANTRA SADHANA OWN YOUR HOME AS PER NEED</font><BR>
<b>NOTE : We does not provide any CERTIFICATE in any class.<br>
Mantra sadhana siddhi depend on sadhak's faith and devotion on Guru , Isht and Mantra.</b><br></font>

<br>
</p>
                         </h3><br>
                        <div class="btn-holder text-center"><br>

                          <a href="contact.php" class="btn btn-primary" >Contact Now</a>
                          
                        </div>
<br><br>
                        </div>

                    </div> <!-- /.cause -->
                    
                </div>


                
                 <div class="col-md-3 col-sm-6">

                   <?php include "sidebar.php" ?>

                </div>

            </div>

        </div>
        
    </div> <!-- /.our-causes -->


    <footer class="main-footer">
<?php include "footer.php" ?>

<!--  Scripts
    ================================================== -->

    <!-- jQuery -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/jquery-1.11.1.min.js"><\/script>')</script>

    <!-- Bootsrap javascript file -->
    <script src="assets/js/bootstrap.min.js"></script>
    
    <!-- owl carouseljavascript file -->
    <script src="assets/js/owl.carousel.min.js"></script>

    <!-- Template main javascript -->
    <script src="assets/js/main.js"></script>
   
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-103796334-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-103796334-1');
</script>
</footer>
</body>
</html>
