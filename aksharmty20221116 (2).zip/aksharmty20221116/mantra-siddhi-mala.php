<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <link rel='shortcut icon' href='logo.jpg' type='image/x-icon' />
        <meta name="msvalidate.01" content="F1178E06F62827B2DD8EF2FE31CC0EBF" />
        <title>मंत्र सिद्ध माला  - कार्य सिद्धि व साधना सिद्धि के लिए </title>
        <meta name="description" content="किसी भी कार्य सिद्धि व साधना सिद्धि में सफलता लिए  मन्त्र सिद्ध माला धारण करना  काफी लाभकारी होता हैं |  ">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Fonts -->
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'>

        <!-- Bootsrap -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <!-- Font awesome -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!-- Owl carousel -->
        <link rel="stylesheet" href="assets/css/owl.carousel.css">

        <!-- Template main Css -->
        <link rel="stylesheet" href="assets/css/style.css">
        
        <!-- Modernizr -->
        <script src="assets/js/modernizr-2.6.2.min.js"></script>

    </head>

    <body>
<?php include "header.php" ?>
       <div class="section-home our-causes">

        <div class="container">

            <h2 class="title-style-1">मन्त्र सिद्ध माला <span class="title-under"></span></h2>

            <div class="row">
<div class="col-md-12">                          
<div class="col-md-9">
<img src="//aksharmty.in/mala.jpg" width="100%" height="300px">    
<br>
<font color="red"><center>
मंत्र सिद्ध माला चित्र से भिन्न हो सकता हैं | <br>
चित्र का उपयोग केवल संकेतमात्र के लिए किया गया हैं |
</center>
</font>
<br>
                <div class="col-md-6 col-sm-6">

                    <div class="cause">
<h2 class="title-style-1">सामान्य मन्त्र सिद्ध माला <span class="title-under"></span></h2>
                        <div class="cause-details">
                        <h3>  
<p>
सामान्य मंत्र सिद्ध माला सभी कार्य व साधना के लिए कारगर हैं | इसको किसी भी तरह के कार्य सिद्धि के लिए या किसी भी मंत्र साधना की सफलता के लिए धारण किया जा सकता हैं | <br>
सामान्य मंत्र सिद्ध माला को " ॐ ह्रीं श्रीं सर्व कार्य सिद्धये ॐ फट " से सिद्ध किया जाता हैं | इसलिए यह माला सभी कार्य और साधना के लिए कार्य करती हैं | <br>
<br><b>मूल्य : रु 2100 प्रति माला <br></b>

<b>Material : as per availability</b><br>
<b>Color : as per availability</b><br>
<b>Dispatch Time : Within 72 Hours of payment</b><br>
</p>
                         </h3>
                        </div>

                    </div> <!-- /.cause -->
                    
                </div>


                <div class="col-md-6 col-sm-6">
                    <div class="cause">
                        <h2 class="title-style-1">विशेष मन्त्र सिद्ध माला <span class="title-under"></span></h2>
                <h3>
                   विशेष मंत्र सिद्ध माला कोई भी जातक अपने किसी इच्छापूर्ति के लिए सिद्ध करवा कर धारण कर सकता हैं | जिससे जातक को उसके विशेष इच्छापूर्ति  के लिए ब्रह्माण्ड  से विशेष ऊर्जा की प्राप्ति हो |<br>
विशेष मंत्र सिद्ध माला जातक के किसी एक विशेष इच्छा के अनुसार उचित मंत्र का चुनाव करके माला को मंत्र से सिद्ध किया जाता हैं |  <br>
<br><b>मूल्य : रु 21000  प्रति माला </b><br>
<b>Material : as per availability</b><br>
<b>Color : as per availability</b><br>
<b>Dispatch Time : Within 07 Days of payment</b><br>
                </h3>        
                </div>
                </div>
<div class="col-md-12">       
नोट : मंत्र सिद्ध माला श्रद्धा और विश्वास पर कार्य करती हैं | जातक के कार्य सिद्धि उसके श्रद्धा और विश्वास पर निर्भर करेंगी | इसलिए इस  पर किसी भी प्रकार का विवाद स्वीकार नहीं किया जायेगा | <br>
किसी भी प्रकार से धन वापसी का अनुरोध स्वीकार नहीं होगा | <br>
    <div class="btn-holder text-center"><br>

                          <a href="contact.php" class="btn btn-primary" >Contact Now</a>
                          <br><br>
                        </div>
                        </div>
                        </div>           
                 <div class="col-md-3 col-sm-6">

                   <?php include "sidebar.php" ?>

                </div>

            </div>

        </div>
        
    </div> <!-- /.our-causes -->


    


    <footer class="main-footer">
<?php include "footer.php" ?>

<!--  Scripts
    ================================================== -->

    <!-- jQuery -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/jquery-1.11.1.min.js"><\/script>')</script>

    <!-- Bootsrap javascript file -->
    <script src="assets/js/bootstrap.min.js"></script>
    
    <!-- owl carouseljavascript file -->
    <script src="assets/js/owl.carousel.min.js"></script>

    <!-- Template main javascript -->
    <script src="assets/js/main.js"></script>
   
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-103796334-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-103796334-1');
</script>
</footer>
</body>
</html>
