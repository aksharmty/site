<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <link rel='shortcut icon' href='favicon.jpg' type='image/x-icon' />
        <title>Contact | AKSHAR MANTRA TANTRA YANTRA</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Fonts -->
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'>

        <!-- Bootsrap -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        
        <!-- Owl carousel -->
        <link rel="stylesheet" href="assets/css/owl.carousel.css">

        <!-- Template main Css -->
        <link rel="stylesheet" href="assets/css/style.css">
        
        <!-- Modernizr -->
        <script src="assets/js/modernizr-2.6.2.min.js"></script>


    </head>

    <body>
        <?php include "header.php" ?>
       <div class="main-container">

		<div class="container">

			<div class="row fadeIn animated">
			    
				<div class="col-md-9">
	<h2 class="title-style-1">Akshar Mantra Tantra Yantra Contact
 <span class="title-under"></span></h2>

	

				<font size="5" color="black">Akshar Mantra Tantra Yantra Contact Details : </font>

					<p>
						<font size="3" color="black"><p>Akshar Mantra Tantra Yantra<br>J-34/209,West Sagar Pur<br>New Delhi-110046<br>Contact No.9213816442.<br>
						Email : aksharmty@ymail.com</p>
						<p><a href="https://api.whatsapp.com/send?phone=919213816442&text=Hi,%20Akshar%20Mantra%20Tantra%20Yantra" class="btn btn-primary">Whatsapp Now</a></p>
    <p><h3>For our location set <b><a href="https://www.google.co.in/maps/dir/28.6062171,77.0923532/akshar+mantra+tantra+yantra,+J-34%2F209,lane+no.4,+West+Sagarpur,+Delhi,+110046/@28.6062054,77.0901392,17z/data=!3m1!4b1!4m9!4m8!1m1!4e1!1m5!1m1!1s0x390d022c8520fc7f:0xe937b4e49bc05dd6!2m2!1d77.0923025!2d28.6062034"target="_blank">AKSHAR MANTRA TANTRA YANTRA</a></b> in Google Map</h3></p></font>
</p>

<center>

<div class="mapouter"><div class="gmap_canvas"><iframe width="100%" height="300" id="gmap_canvas" src="https://maps.google.com/maps?q=akshar%20mantra%20tantra%20yantra&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><br><style>.mapouter{position:relative;text-align:right;height:300px;width:100%;}</style><a href="https://www.embedgooglemap.net">embedded google search</a><style>.gmap_canvas {overflow:hidden;background:none!important;height:300px;width:100%;}</style></div></div>

    </center>
				</div>
				<div class="col-md-3">
<?php include "sidebar.php" ?>
		
				    </div>

		        	</div> <!-- /.row -->

			         </div> <!-- /.row -->

			      
			    </div> 

<footer class="main-footer">

      <?php include "footer.php" ?>
        </div>
        
    </footer> <!-- main-footer -->
        </body>
        </html>