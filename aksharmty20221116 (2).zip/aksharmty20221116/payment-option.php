<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <link rel='shortcut icon' href='logo.jpg' type='image/x-icon' />
        <meta name="msvalidate.01" content="F1178E06F62827B2DD8EF2FE31CC0EBF" />
        <title>Akshar Mantra Tantra Yantra | Payment Option</title>
        <meta name="description" content="Akshar Mantra Tantra Yantra accept Payment in">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Fonts -->
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'>

        <!-- Bootsrap -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <!-- Font awesome -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!-- Owl carousel -->
        <link rel="stylesheet" href="assets/css/owl.carousel.css">

        <!-- Template main Css -->
        <link rel="stylesheet" href="assets/css/style.css">
        
        <!-- Modernizr -->
        <script src="assets/js/modernizr-2.6.2.min.js"></script>
    </head>

    <body>
<?php include "header.php" ?>
       <div class="section-home our-causes">

        <div class="container">

            <h2 class="title-style-1">Payment Option <span class="title-under"></span></h2>

            <div class="row">

                <div class="col-md-3 col-sm-6">

                    <center><img src="rajpic.jpg" alt="Mantra Sadhak Mr.Raj Kumar"><br>

                        <h2>Mr.Raj Kumar <br> Mantra Sadhak
                        </h2></center>
                    
                </div> 

                <div class="col-md-6 col-sm-6">

                    <div class="cause">

                        <div class="cause-details">
                        <h3>You can use any option for deposit :<br>
                        <b>PAYTM</b> : <br> Paytm No. 9213816442<br>
                        <b>UPI : </b>9213816442@paytm<br>
                        <b>Bank Deposit :</b><br>
<b>SBI BANK DETAILS:</b><br>
Account Name: RAJ KUMAR<br>
Saving A/c No: 34047891546<br>
Bank Name ; SBI BANK<br>
Branch: C-BLOCK,JANAK PURI<br>
IFSC Code SBIN0050258<br>
<b>AXIS BANK DETAILS:</b><br>
Account Name: RAJ KUMAR<br>
Saving A/c No: 911010058791914<br>
Bank Name ; AXIS BANK<br>
Bank Branch: PALAM DELHI<br>
IFSC Code UTIB0000132<br>
<b>ICICI BANK DETAILS:</b><br>
Account Name: RAJ KUMAR<br>
Saving A/c No: 900101598401<br>
Bank Name ; ICICI BANK<br>
Bank Branch: Janak Puri DELHI<br>
IFSC Code : ICIC0006629<br>
<b>Paypal : </b><br>
Paypal Id : aksharmty@ymail.com 
</h3><br>
                        <div class="btn-holder text-center"><br>
<h3>More Details
                          <a href="contact.php" class="btn btn-primary" >Contact</a>
 </h3>                         
                        </div>
<br><br>
                        </div>

                    </div> <!-- /.cause -->
                    
                </div>


                
                 <div class="col-md-3 col-sm-6">

                   <?php include "sidebar.php" ?>

                </div>

            </div>

        </div>
        
    </div> <!-- /.our-causes -->


    


    <footer class="main-footer">
<?php include "footer.php" ?> 

<!--  Scripts
    ================================================== -->

    <!-- jQuery -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/jquery-1.11.1.min.js"><\/script>')</script>

    <!-- Bootsrap javascript file -->
    <script src="assets/js/bootstrap.min.js"></script>
    
    <!-- owl carouseljavascript file -->
    <script src="assets/js/owl.carousel.min.js"></script>

    <!-- Template main javascript -->
    <script src="assets/js/main.js"></script>
   
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-103796334-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-103796334-1');
</script>
</footer>
</body>
</html>
