<footer class="main-footer">

        <div class="footer-top">
        </div>
        <div class="footer-main">
            <div class="container">
               <div class="row">
                    <div class="col-md-4">

                        <div class="footer-col">
                            <div class="footer-content">
                         <iframe src="https://youtube.com/embed/9W4AKZJBQFM" width="250px" height="200px" frameborder="0" allowfullscreen></iframe>
                    </div>
                   </div>

                    </div>

                    <div class="col-md-4">

                        <div class="footer-col">
                            <div class="footer-content">

<a href="https://adquash.com"target="_blank"><img src="adquash-logo-new.png" width="250px" height="200px"></a>

       </div>
                   </div>

                    </div>

                    <div class="col-md-4">

                        <div class="footer-col">
                          

                            <div class="footer-content">

                                <a href="//sakhihosting.in"target="_blank"><img src="dedicatedserver.png" width="250px" height="200px"></a>
                                </div>

                                </div>
                            </div>
                            
                        </div>

                    </div>
                           <div class="clearfix"></div>



                </div>

        <div class="footer-bottom">

            <div class="container text-left">
              <a href="index.php">अक्षर मंत्र तंत्र यंत्र</a>   @ copyrights 2005-<?php echo date("y") ;?> - & Design by <a href="https://sakhihosting.in" target="_blank">Sakhi Hosting</a>
            </div>
            <div class="container text-right"><a href="terms.php" target="_blank">Terms</a></div>
        </div>
        
    </footer> <!-- main-footer -->

    <!--  Scripts
    ================================================== -->

    <!-- jQuery -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/jquery-1.11.1.min.js"><\/script>')</script>

    <!-- Bootsrap javascript file -->
    <!-- script src="assets/js/bootstrap.min.js"></script -->
    
    <!-- owl carouseljavascript file -->
    <script src="assets/js/owl.carousel.min.js"></script>

    <!-- Template main javascript -->
    <script src="assets/js/main.js"></script>

   <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-103796334-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-103796334-1');
</script>