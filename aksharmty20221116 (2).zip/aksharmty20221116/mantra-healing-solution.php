<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <link rel='shortcut icon' href='logo.jpg' type='image/x-icon' />
        <meta name="msvalidate.01" content="F1178E06F62827B2DD8EF2FE31CC0EBF" />
        <title>समस्या निवारण के लिए 
मन्त्र हीलिंग | Akshar Mantra Tantra Yantra</title>
        <meta name="description" content="learn varn mantra ">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Fonts -->
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'>

        <!-- Bootsrap -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <!-- Font awesome -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!-- Owl carousel -->
        <link rel="stylesheet" href="assets/css/owl.carousel.css">

        <!-- Template main Css -->
        <link rel="stylesheet" href="assets/css/style.css">
        
        <!-- Modernizr -->
        <script src="assets/js/modernizr-2.6.2.min.js"></script>

    </head>

    <body>
<?php include "header.php" ?>
       <div class="section-home our-causes">

        <div class="container">

            <h2 class="title-style-1">समस्या निवारण के लिए 
मन्त्र हीलिंग <span class="title-under"></span></h2>

            <div class="row">          

                <div class="col-md-9 col-sm-6">

                    <div class="cause">

                        <div class="cause-details">
                        <h3>  
                    
					<p>
मंत्र हीलिंग समस्या निवारण की प्राचीन पद्धति है | प्राचीन काल से ही इस पद्धति का उपयोग करके लोग अपने समस्यो का समाधान करते रहें हैं | इस पद्धति से सभी तरह के दोषो का निवारण कर जीवन को सुखद वनाया जा सकता हैं | <br>
मंत्र हीलिंग की सब से खास बात हैं कि इस का कोई दुष्प्रभाव नहीं होता हैं | इसलिए इसका उपयोग करने से केवल लाभ होता हैं | <br>
मंत्र हीलिंग का उपयोग निम्न दोष के लिए किया जाता हैं  :<br>
ग्रह दोष <br>
वास्तु दोष <br>
रोग <br>
तन्त्र दोष<br> 
नज़र दोष <br>
देव दोष <br>
पितृ दोष <br>
पूर्वजन्म के दोष आदि | 

<br><br>मन्त्र उपचार कम से कम तीन दिन अवश्य ले |<br>
<b>नोट : </b> डिस्टेंस मंत्र हीलिंग प्रत्यक्ष मंत्र हीलिंग के समान काम करती हैैं | तो आप  डिस्टेंस मन्त्र उपचार भी ले सकते हैं | <br>
डिस्टेंस मन्त्र उपचार के लिए जातक के फोटो की आवश्यकता होती हैं | 
<br>
<br>
</p><HR style="border-top: 5px solid red;">
    <br>
<b>Duration : 5-15 Minute Daily</b><br>
<b>Fee : INR.2100 per session</b><br>
<b>Yantra & Mala charge additional </b><br>
<br>

                         </h3><br>
                        <div class="btn-holder text-center"><br>

                          <a href="contact.php" class="btn btn-primary" >Contact Now</a>
                          
                        </div>
<br><br>
                        </div>

                    </div> <!-- /.cause -->
                    
                </div>


                
                 <div class="col-md-3 col-sm-6">

<?php include "sidebar.php" ?>

                </div>

            </div>

        </div>
        
    </div> <!-- /.our-causes -->


    


    <footer class="main-footer">
<?php include "footer.php" ?>

<!--  Scripts
    ================================================== -->

    <!-- jQuery -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/jquery-1.11.1.min.js"><\/script>')</script>

    <!-- Bootsrap javascript file -->
    <script src="assets/js/bootstrap.min.js"></script>
    
    <!-- owl carouseljavascript file -->
    <script src="assets/js/owl.carousel.min.js"></script>

    <!-- Template main javascript -->
    <script src="assets/js/main.js"></script>
   
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-103796334-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-103796334-1');
</script>
</footer>
</body>
</html
